
export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: number;
  category: 'care' | 'habit' | 'evolution' | 'interaction';
  requirement: {
    type: 'level' | 'interactions' | 'streak' | 'stat' | 'evolution';
    value: number | string;
  };
}

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_interaction',
    name: 'First Friend',
    description: 'Interact with your pet for the first time',
    icon: '🤝',
    unlocked: false,
    category: 'interaction',
    requirement: { type: 'interactions', value: 1 }
  },
  {
    id: 'level_5',
    name: 'Growing Strong',
    description: 'Reach level 5',
    icon: '⭐',
    unlocked: false,
    category: 'care',
    requirement: { type: 'level', value: 5 }
  },
  {
    id: 'evolution_teen',
    name: 'Teenage Years',
    description: 'Evolve to teen stage',
    icon: '🌱',
    unlocked: false,
    category: 'evolution',
    requirement: { type: 'evolution', value: 'teen' }
  },
  {
    id: 'evolution_adult',
    name: 'All Grown Up',
    description: 'Evolve to adult stage',
    icon: '🌳',
    unlocked: false,
    category: 'evolution',
    requirement: { type: 'evolution', value: 'adult' }
  },
  {
    id: 'habit_streak_7',
    name: 'Week Warrior',
    description: 'Maintain a 7-day habit streak',
    icon: '🔥',
    unlocked: false,
    category: 'habit',
    requirement: { type: 'streak', value: 7 }
  },
  {
    id: 'perfect_stats',
    name: 'Perfect Care',
    description: 'Have all stats above 90%',
    icon: '💎',
    unlocked: false,
    category: 'care',
    requirement: { type: 'stat', value: 90 }
  },
  {
    id: 'hundred_interactions',
    name: 'Best Friend',
    description: 'Reach 100 total interactions',
    icon: '💖',
    unlocked: false,
    category: 'interaction',
    requirement: { type: 'interactions', value: 100 }
  }
];
