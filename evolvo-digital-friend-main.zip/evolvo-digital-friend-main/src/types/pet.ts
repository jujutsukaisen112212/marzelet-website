
export interface PetState {
  name: string;
  level: number;
  happiness: number;
  health: number;
  energy: number;
  hunger: number;
  cleanliness: number;
  mood: 'happy' | 'neutral' | 'sad';
  evolutionStage: 'baby' | 'teen' | 'adult';
  petType: string;
  lastFed: number;
  lastPlayed: number;
  lastCleaned: number;
  totalInteractions: number;
}

export type Action = 'feed' | 'play' | 'sleep' | 'clean';

export interface Habit {
  id: number;
  name: string;
  completed: boolean;
  streak: number;
  impact: 'happiness' | 'health' | 'energy';
}
