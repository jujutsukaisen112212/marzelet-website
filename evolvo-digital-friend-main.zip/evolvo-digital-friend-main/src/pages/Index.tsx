import { useState, useEffect } from 'react';
import PetDisplay from '@/components/PetDisplay';
import ActionPanel from '@/components/ActionPanel';
import StatsPanel from '@/components/StatsPanel';
import HabitTracker from '@/components/HabitTracker';
import AchievementPanel from '@/components/AchievementPanel';
import PetCustomization from '@/components/PetCustomization';
import { PetState, Action, Habit } from '@/types/pet';
import { useAchievements } from '@/hooks/useAchievements';
import { saveToStorage, loadFromStorage } from '@/utils/storage';
import { toast } from '@/hooks/use-toast';

const Index = () => {
  const [petState, setPetState] = useState<PetState>({
    name: 'Buddy',
    level: 1,
    happiness: 75,
    health: 80,
    energy: 60,
    hunger: 40,
    cleanliness: 90,
    mood: 'happy',
    evolutionStage: 'baby',
    petType: 'classic',
    lastFed: Date.now() - 3600000, // 1 hour ago
    lastPlayed: Date.now() - 7200000, // 2 hours ago
    lastCleaned: Date.now() - 1800000, // 30 minutes ago
    totalInteractions: 15
  });

  const [habits, setHabits] = useState<Habit[]>([
    { id: 1, name: 'Exercise', completed: false, streak: 3, impact: 'energy' },
    { id: 2, name: 'Healthy Eating', completed: true, streak: 5, impact: 'health' },
    { id: 3, name: 'Reading', completed: false, streak: 2, impact: 'happiness' },
    { id: 4, name: 'Sleep 8hrs', completed: true, streak: 7, impact: 'energy' }
  ]);

  const achievements = useAchievements(petState, habits);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = loadFromStorage();
    if (savedData) {
      setPetState(savedData.petState);
      setHabits(savedData.habits);
      toast({
        title: "Welcome back!",
        description: "Your pet missed you! 🐾",
      });
    }
  }, []);

  // Save data to localStorage whenever state changes
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      saveToStorage({
        petState,
        habits,
        achievements,
        lastSaved: Date.now()
      });
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [petState, habits, achievements]);

  // Update pet state based on time and habits
  useEffect(() => {
    const interval = setInterval(() => {
      setPetState(prev => {
        let newState = { ...prev };
        
        // Natural decay over time
        const now = Date.now();
        const hoursSinceLastFed = (now - prev.lastFed) / (1000 * 60 * 60);
        const hoursSinceLastPlayed = (now - prev.lastPlayed) / (1000 * 60 * 60);
        
        if (hoursSinceLastFed > 2) newState.hunger = Math.min(100, prev.hunger + 5);
        if (hoursSinceLastPlayed > 3) newState.happiness = Math.max(0, prev.happiness - 3);
        
        newState.energy = Math.max(0, prev.energy - 1);
        newState.cleanliness = Math.max(0, prev.cleanliness - 2);
        
        // Determine mood based on stats
        const avgStat = (newState.happiness + newState.health + newState.energy + (100 - newState.hunger)) / 4;
        if (avgStat > 70) newState.mood = 'happy';
        else if (avgStat > 40) newState.mood = 'neutral';
        else newState.mood = 'sad';
        
        // Evolution based on level and care
        if (newState.level >= 5 && avgStat > 80) newState.evolutionStage = 'adult';
        else if (newState.level >= 3 && avgStat > 60) newState.evolutionStage = 'teen';
        
        return newState;
      });
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const handleAction = (action: Action) => {
    setPetState(prev => {
      const newState = { ...prev };
      const now = Date.now();
      
      switch (action) {
        case 'feed':
          newState.hunger = Math.max(0, prev.hunger - 30);
          newState.health = Math.min(100, prev.health + 5);
          newState.lastFed = now;
          break;
        case 'play':
          newState.happiness = Math.min(100, prev.happiness + 25);
          newState.energy = Math.max(0, prev.energy - 15);
          newState.lastPlayed = now;
          break;
        case 'sleep':
          newState.energy = Math.min(100, prev.energy + 40);
          newState.health = Math.min(100, prev.health + 10);
          break;
        case 'clean':
          newState.cleanliness = 100;
          newState.happiness = Math.min(100, prev.happiness + 10);
          newState.lastCleaned = now;
          break;
      }
      
      newState.totalInteractions = prev.totalInteractions + 1;
      
      if (newState.totalInteractions % 20 === 0) {
        newState.level = prev.level + 1;
        toast({
          title: "🎉 Level Up!",
          description: `${newState.name} reached level ${newState.level}!`,
        });
      }
      
      return newState;
    });
  };

  const handleHabitToggle = (habitId: number) => {
    setHabits(prev => prev.map(habit => {
      if (habit.id === habitId) {
        const completed = !habit.completed;
        const newStreak = completed ? habit.streak + 1 : Math.max(0, habit.streak - 1);
        
        if (completed) {
          setPetState(petPrev => ({
            ...petPrev,
            [habit.impact]: Math.min(100, petPrev[habit.impact as keyof PetState] as number + 15)
          }));
        }
        
        return { ...habit, completed, streak: newStreak };
      }
      return habit;
    }));
  };

  const handleNameChange = (name: string) => {
    setPetState(prev => ({ ...prev, name }));
    toast({
      title: "Name Updated!",
      description: `Your pet is now called ${name}! 🏷️`,
    });
  };

  const handlePetTypeChange = (petType: string) => {
    setPetState(prev => ({ ...prev, petType }));
    toast({
      title: "New Look!",
      description: "Your pet has a new appearance! ✨",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
            Virtual Pet Companion
          </h1>
          <p className="text-gray-600">Your digital friend that grows with your habits</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Pet Display - Main Area */}
          <div className="lg:col-span-2">
            <PetDisplay petState={petState} />
            <ActionPanel onAction={handleAction} petState={petState} />
          </div>

          {/* Side Panels */}
          <div className="space-y-6">
            <StatsPanel petState={petState} />
            <AchievementPanel achievements={achievements} />
          </div>

          <div className="space-y-6">
            <PetCustomization 
              petState={petState}
              onNameChange={handleNameChange}
              onPetTypeChange={handlePetTypeChange}
            />
            <HabitTracker habits={habits} onHabitToggle={handleHabitToggle} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
