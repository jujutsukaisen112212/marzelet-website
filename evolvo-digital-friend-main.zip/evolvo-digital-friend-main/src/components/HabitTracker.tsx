
import { useState } from 'react';
import { CheckCircle, Circle, Flame, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Habit } from '@/types/pet';

interface HabitTrackerProps {
  habits: Habit[];
  onHabitToggle: (habitId: number) => void;
}

const HabitTracker = ({ habits, onHabitToggle }: HabitTrackerProps) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'happiness': return 'text-pink-500 bg-pink-100';
      case 'health': return 'text-green-500 bg-green-100';
      case 'energy': return 'text-yellow-500 bg-yellow-100';
      default: return 'text-gray-500 bg-gray-100';
    }
  };

  const completedHabits = habits.filter(h => h.completed).length;
  const totalStreak = habits.reduce((sum, h) => sum + h.streak, 0);

  return (
    <div className="bg-white rounded-3xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold text-gray-800">Daily Habits</h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-gray-500 hover:text-gray-700"
        >
          {isExpanded ? '−' : '+'}
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="text-center p-3 bg-blue-50 rounded-xl">
          <Target className="w-5 h-5 text-blue-500 mx-auto mb-1" />
          <p className="text-sm text-gray-600">Completed</p>
          <p className="font-bold text-blue-600">{completedHabits}/{habits.length}</p>
        </div>
        <div className="text-center p-3 bg-orange-50 rounded-xl">
          <Flame className="w-5 h-5 text-orange-500 mx-auto mb-1" />
          <p className="text-sm text-gray-600">Total Streak</p>
          <p className="font-bold text-orange-600">{totalStreak}</p>
        </div>
      </div>

      {isExpanded && (
        <div className="space-y-3">
          {habits.map((habit) => (
            <div 
              key={habit.id} 
              className={`p-4 rounded-xl border-2 transition-all duration-200 cursor-pointer hover:shadow-md ${
                habit.completed 
                  ? 'border-green-200 bg-green-50' 
                  : 'border-gray-200 bg-gray-50 hover:border-gray-300'
              }`}
              onClick={() => onHabitToggle(habit.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {habit.completed ? (
                    <CheckCircle className="w-6 h-6 text-green-500 mr-3 animate-scale-in" />
                  ) : (
                    <Circle className="w-6 h-6 text-gray-400 mr-3" />
                  )}
                  <div>
                    <p className={`font-medium ${habit.completed ? 'text-green-800' : 'text-gray-700'}`}>
                      {habit.name}
                    </p>
                    <div className="flex items-center mt-1">
                      <span className={`text-xs px-2 py-1 rounded-full ${getImpactColor(habit.impact)}`}>
                        +{habit.impact}
                      </span>
                      <div className="flex items-center ml-2 text-orange-500">
                        <Flame className="w-3 h-3 mr-1" />
                        <span className="text-xs font-medium">{habit.streak}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl">
        <p className="text-sm text-gray-600 text-center">
          ✨ Complete habits to boost your pet's stats!
        </p>
      </div>
    </div>
  );
};

export default HabitTracker;
