
import { useState } from 'react';
import { Trophy, Lock, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Achievement } from '@/types/achievement';

interface AchievementPanelProps {
  achievements: Achievement[];
}

const AchievementPanel = ({ achievements }: AchievementPanelProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalCount = achievements.length;

  const categoryColors = {
    care: 'bg-green-100 text-green-700',
    habit: 'bg-blue-100 text-blue-700',
    evolution: 'bg-purple-100 text-purple-700',
    interaction: 'bg-pink-100 text-pink-700'
  };

  return (
    <div className="bg-white rounded-3xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <Trophy className="w-6 h-6 text-yellow-500 mr-2" />
          <h3 className="text-xl font-semibold text-gray-800">Achievements</h3>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-gray-500 hover:text-gray-700"
        >
          {isExpanded ? '−' : '+'}
        </Button>
      </div>

      <div className="mb-4 p-3 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Progress</span>
          <span className="text-sm font-bold text-orange-600">
            {unlockedCount}/{totalCount}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
          <div 
            className="bg-gradient-to-r from-yellow-500 to-orange-500 h-2 rounded-full transition-all duration-500"
            style={{ width: `${(unlockedCount / totalCount) * 100}%` }}
          />
        </div>
      </div>

      {isExpanded && (
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {achievements.map((achievement) => (
            <div 
              key={achievement.id}
              className={`p-3 rounded-xl border-2 transition-all duration-200 ${
                achievement.unlocked 
                  ? 'border-yellow-200 bg-yellow-50' 
                  : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className={`text-2xl mr-3 ${achievement.unlocked ? '' : 'grayscale opacity-50'}`}>
                    {achievement.unlocked ? achievement.icon : '🔒'}
                  </div>
                  <div>
                    <p className={`font-medium ${achievement.unlocked ? 'text-yellow-800' : 'text-gray-700'}`}>
                      {achievement.name}
                    </p>
                    <p className="text-xs text-gray-600 mb-1">
                      {achievement.description}
                    </p>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${categoryColors[achievement.category]}`}>
                        {achievement.category}
                      </span>
                      {achievement.unlocked && achievement.unlockedAt && (
                        <div className="flex items-center text-xs text-gray-500">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(achievement.unlockedAt).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                {!achievement.unlocked && (
                  <Lock className="w-4 h-4 text-gray-400" />
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AchievementPanel;
