
import { Heart, Zap, Apple, Droplets, TrendingUp } from 'lucide-react';
import { PetState } from '@/types/pet';

interface StatsPanelProps {
  petState: PetState;
}

const StatsPanel = ({ petState }: StatsPanelProps) => {
  const stats = [
    {
      label: 'Happiness',
      value: petState.happiness,
      icon: Heart,
      color: 'text-red-500',
      bgColor: 'bg-red-100',
      barColor: 'bg-red-500'
    },
    {
      label: 'Health',
      value: petState.health,
      icon: TrendingUp,
      color: 'text-green-500',
      bgColor: 'bg-green-100',
      barColor: 'bg-green-500'
    },
    {
      label: 'Energy',
      value: petState.energy,
      icon: Zap,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-100',
      barColor: 'bg-yellow-500'
    },
    {
      label: 'Hunger',
      value: 100 - petState.hunger, // Inverted so full = good
      icon: Apple,
      color: 'text-orange-500',
      bgColor: 'bg-orange-100',
      barColor: 'bg-orange-500'
    },
    {
      label: 'Cleanliness',
      value: petState.cleanliness,
      icon: Droplets,
      color: 'text-blue-500',
      bgColor: 'bg-blue-100',
      barColor: 'bg-blue-500'
    }
  ];

  const getStatColor = (value: number) => {
    if (value >= 70) return 'text-green-600';
    if (value >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-3xl shadow-lg p-6">
      <h3 className="text-xl font-semibold text-gray-800 mb-6">Pet Stats</h3>
      
      <div className="space-y-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="relative">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <div className={`p-2 rounded-full ${stat.bgColor} mr-3`}>
                    <Icon className={`w-4 h-4 ${stat.color}`} />
                  </div>
                  <span className="text-sm font-medium text-gray-700">{stat.label}</span>
                </div>
                <span className={`text-sm font-bold ${getStatColor(stat.value)}`}>
                  {Math.round(stat.value)}%
                </span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div 
                  className={`${stat.barColor} h-2 rounded-full transition-all duration-700 ease-out`}
                  style={{ width: `${Math.max(0, Math.min(100, stat.value))}%` }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl">
        <div className="text-center">
          <p className="text-sm font-medium text-gray-700 mb-1">Overall Wellness</p>
          <p className="text-2xl font-bold text-indigo-600">
            {Math.round((petState.happiness + petState.health + petState.energy + (100 - petState.hunger) + petState.cleanliness) / 5)}%
          </p>
        </div>
      </div>
    </div>
  );
};

export default StatsPanel;
