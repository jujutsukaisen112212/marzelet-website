
import { useState, useEffect } from 'react';
import { Heart, Star, Sparkles } from 'lucide-react';
import { PetState } from '@/types/pet';

interface PetDisplayProps {
  petState: PetState;
}

const PetDisplay = ({ petState }: PetDisplayProps) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [previousLevel, setPreviousLevel] = useState(petState.level);

  useEffect(() => {
    if (petState.level > previousLevel) {
      setShowLevelUp(true);
      setTimeout(() => setShowLevelUp(false), 3000);
    }
    setPreviousLevel(petState.level);
  }, [petState.level, previousLevel]);

  const getPetEmoji = () => {
    const stage = petState.evolutionStage;
    const mood = petState.mood;
    const petType = petState.petType || 'classic';
    
    const petTypes = {
      classic: { baby: '🐣', teen: '🐕', adult: '🦊' },
      cat: { baby: '🐱', teen: '🐈', adult: '🦁' },
      dragon: { baby: '🥚', teen: '🐲', adult: '🐉' },
      robot: { baby: '🤖', teen: '🤖', adult: '🤖' }
    };
    
    const selectedType = petTypes[petType as keyof typeof petTypes] || petTypes.classic;
    
    if (mood === 'sad') return '😴';
    return selectedType[stage as keyof typeof selectedType];
  };

  const handlePetClick = () => {
    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 600);
  };

  return (
    <div className="bg-white rounded-3xl shadow-xl p-8 mb-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-purple-50 opacity-50"></div>
      
      {/* Level up animation */}
      {showLevelUp && (
        <div className="absolute inset-0 flex items-center justify-center z-20 animate-scale-in">
          <div className="bg-yellow-400 text-white px-6 py-3 rounded-full font-bold text-lg shadow-lg animate-pulse">
            <Star className="inline-block w-5 h-5 mr-2" />
            Level Up! Level {petState.level}
            <Star className="inline-block w-5 h-5 ml-2" />
          </div>
        </div>
      )}

      <div className="relative z-10">
        {/* Pet Info Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{petState.name}</h2>
            <p className="text-gray-600 capitalize">
              {petState.petType || 'Classic'} • {petState.evolutionStage} • Level {petState.level}
            </p>
          </div>
          <div className="text-right">
            <div className="flex items-center text-red-500 mb-1">
              <Heart className="w-4 h-4 mr-1" />
              <span className="text-sm font-medium">Mood: {petState.mood}</span>
            </div>
            <div className="text-xs text-gray-500">
              {petState.totalInteractions} interactions
            </div>
          </div>
        </div>

        {/* Pet Character */}
        <div className="flex justify-center mb-6">
          <div 
            className={`relative cursor-pointer transition-transform duration-300 ${
              isAnimating ? 'animate-bounce scale-110' : 'hover:scale-105'
            }`}
            onClick={handlePetClick}
          >
            <div className="text-9xl select-none relative">
              {getPetEmoji()}
              {petState.mood === 'happy' && (
                <div className="absolute -top-2 -right-2 animate-pulse">
                  <Sparkles className="w-8 h-8 text-yellow-400" />
                </div>
              )}
            </div>
            
            {/* Floating hearts animation */}
            {isAnimating && (
              <>
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 animate-fade-in">
                  <Heart className="w-6 h-6 text-pink-500 animate-bounce" style={{ animationDelay: '0.1s' }} />
                </div>
                <div className="absolute top-4 right-0 animate-fade-in">
                  <Heart className="w-4 h-4 text-red-500 animate-bounce" style={{ animationDelay: '0.2s' }} />
                </div>
                <div className="absolute top-2 left-0 animate-fade-in">
                  <Heart className="w-5 h-5 text-pink-400 animate-bounce" style={{ animationDelay: '0.3s' }} />
                </div>
              </>
            )}
          </div>
        </div>

        {/* Status Message */}
        <div className="text-center">
          <p className="text-gray-700 italic">
            {petState.mood === 'happy' && "I'm feeling great! Thanks for taking good care of me! 🌟"}
            {petState.mood === 'neutral' && "I'm doing okay. Maybe we could play together? 🤔"}
            {petState.mood === 'sad' && "I need some attention... Please take care of me 🥺"}
          </p>
        </div>

        {/* Evolution Progress */}
        {petState.evolutionStage !== 'adult' && (
          <div className="mt-6 p-4 bg-gradient-to-r from-purple-100 to-pink-100 rounded-xl">
            <p className="text-sm text-gray-600 mb-2">Evolution Progress</p>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-500"
                style={{ 
                  width: `${Math.min(100, (petState.level / (petState.evolutionStage === 'baby' ? 3 : 5)) * 100)}%` 
                }}
              ></div>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {petState.evolutionStage === 'baby' ? 'Next: Teen stage' : 'Next: Adult stage'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PetDisplay;
