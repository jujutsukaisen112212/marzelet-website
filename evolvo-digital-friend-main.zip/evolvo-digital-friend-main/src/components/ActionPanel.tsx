
import { Apple, Gamepad2, Moon, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PetState, Action } from '@/types/pet';

interface ActionPanelProps {
  onAction: (action: Action) => void;
  petState: PetState;
}

const ActionPanel = ({ onAction, petState }: ActionPanelProps) => {
  const actions = [
    {
      id: 'feed' as Action,
      label: 'Feed',
      icon: Apple,
      color: 'bg-green-500 hover:bg-green-600',
      disabled: petState.hunger < 20,
      description: 'Give your pet some food'
    },
    {
      id: 'play' as Action,
      label: 'Play',
      icon: Gamepad2,
      color: 'bg-blue-500 hover:bg-blue-600',
      disabled: petState.energy < 20,
      description: 'Play games together'
    },
    {
      id: 'sleep' as Action,
      label: 'Sleep',
      icon: Moon,
      color: 'bg-purple-500 hover:bg-purple-600',
      disabled: petState.energy > 80,
      description: 'Help your pet rest'
    },
    {
      id: 'clean' as Action,
      label: 'Clean',
      icon: Sparkles,
      color: 'bg-yellow-500 hover:bg-yellow-600',
      disabled: petState.cleanliness > 80,
      description: 'Keep your pet clean'
    }
  ];

  return (
    <div className="bg-white rounded-3xl shadow-lg p-6">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">Pet Actions</h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <div key={action.id} className="text-center">
              <Button
                onClick={() => onAction(action.id)}
                disabled={action.disabled}
                className={`${action.color} text-white w-full h-16 rounded-2xl mb-2 transition-all duration-200 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100`}
              >
                <div className="flex flex-col items-center">
                  <Icon className="w-6 h-6 mb-1" />
                  <span className="text-sm font-medium">{action.label}</span>
                </div>
              </Button>
              <p className="text-xs text-gray-500">{action.description}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-gray-50 rounded-xl">
        <p className="text-sm text-gray-600 text-center">
          💡 Tip: Different actions become available based on your pet's needs!
        </p>
      </div>
    </div>
  );
};

export default ActionPanel;
