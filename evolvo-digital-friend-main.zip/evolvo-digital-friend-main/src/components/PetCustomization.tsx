
import { useState } from 'react';
import { Palette, User, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PetState } from '@/types/pet';

interface PetCustomizationProps {
  petState: PetState;
  onNameChange: (name: string) => void;
  onPetTypeChange: (type: string) => void;
}

const PetCustomization = ({ petState, onNameChange, onPetTypeChange }: PetCustomizationProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempName, setTempName] = useState(petState.name);
  
  const petTypes = [
    { id: 'classic', name: 'Classic', emojis: { baby: '🐣', teen: '🐕', adult: '🦊' } },
    { id: 'cat', name: 'Cat', emojis: { baby: '🐱', teen: '🐈', adult: '🦁' } },
    { id: 'dragon', name: 'Dragon', emojis: { baby: '🥚', teen: '🐲', adult: '🐉' } },
    { id: 'robot', name: 'Robot', emojis: { baby: '🤖', teen: '🤖', adult: '🤖' } }
  ];

  const handleNameSave = () => {
    if (tempName.trim()) {
      onNameChange(tempName.trim());
      setIsEditing(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-lg p-6">
      <div className="flex items-center mb-4">
        <Palette className="w-6 h-6 text-purple-500 mr-2" />
        <h3 className="text-xl font-semibold text-gray-800">Customize Pet</h3>
      </div>

      {/* Name Customization */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Pet Name</label>
        {isEditing ? (
          <div className="flex gap-2">
            <input
              type="text"
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              maxLength={20}
              onKeyDown={(e) => e.key === 'Enter' && handleNameSave()}
            />
            <Button onClick={handleNameSave} size="sm">Save</Button>
            <Button 
              onClick={() => {
                setIsEditing(false);
                setTempName(petState.name);
              }} 
              variant="outline" 
              size="sm"
            >
              Cancel
            </Button>
          </div>
        ) : (
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <User className="w-4 h-4 text-gray-500 mr-2" />
              <span className="font-medium">{petState.name}</span>
            </div>
            <Button onClick={() => setIsEditing(true)} variant="ghost" size="sm">
              Edit
            </Button>
          </div>
        )}
      </div>

      {/* Pet Type Selection */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-3">Pet Type</label>
        <div className="grid grid-cols-2 gap-3">
          {petTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => onPetTypeChange(type.id)}
              className={`p-4 rounded-xl border-2 transition-all duration-200 hover:scale-105 ${
                petState.petType === type.id
                  ? 'border-purple-500 bg-purple-50'
                  : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="text-center">
                <div className="text-2xl mb-2">
                  {type.emojis[petState.evolutionStage as keyof typeof type.emojis]}
                </div>
                <p className="text-sm font-medium text-gray-700">{type.name}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Unlockable Accessories (Future Feature) */}
      <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl">
        <div className="flex items-center text-purple-600 mb-2">
          <Sparkles className="w-4 h-4 mr-2" />
          <span className="text-sm font-medium">Coming Soon</span>
        </div>
        <p className="text-xs text-gray-600">
          Unlock accessories and customizations as your pet grows!
        </p>
      </div>
    </div>
  );
};

export default PetCustomization;
