
export interface StoredData {
  petState: any;
  habits: any[];
  achievements: any[];
  lastSaved: number;
}

export const saveToStorage = (data: StoredData) => {
  try {
    localStorage.setItem('virtualPetData', JSON.stringify({
      ...data,
      lastSaved: Date.now()
    }));
  } catch (error) {
    console.error('Failed to save data:', error);
  }
};

export const loadFromStorage = (): StoredData | null => {
  try {
    const data = localStorage.getItem('virtualPetData');
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Failed to load data:', error);
    return null;
  }
};

export const clearStorage = () => {
  try {
    localStorage.removeItem('virtualPetData');
  } catch (error) {
    console.error('Failed to clear data:', error);
  }
};
