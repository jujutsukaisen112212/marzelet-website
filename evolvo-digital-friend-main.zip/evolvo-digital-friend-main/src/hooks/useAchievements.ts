
import { useState, useEffect } from 'react';
import { Achievement, ACHIEVEMENTS } from '@/types/achievement';
import { PetState, Habit } from '@/types/pet';
import { toast } from '@/hooks/use-toast';

export const useAchievements = (petState: PetState, habits: Habit[]) => {
  const [achievements, setAchievements] = useState<Achievement[]>(ACHIEVEMENTS);

  const checkAchievements = () => {
    setAchievements(prev => {
      let updated = false;
      const newAchievements = prev.map(achievement => {
        if (achievement.unlocked) return achievement;

        let shouldUnlock = false;

        switch (achievement.requirement.type) {
          case 'interactions':
            if (typeof achievement.requirement.value === 'number') {
              shouldUnlock = petState.totalInteractions >= achievement.requirement.value;
            }
            break;
          case 'level':
            if (typeof achievement.requirement.value === 'number') {
              shouldUnlock = petState.level >= achievement.requirement.value;
            }
            break;
          case 'evolution':
            shouldUnlock = petState.evolutionStage === achievement.requirement.value;
            break;
          case 'streak':
            if (typeof achievement.requirement.value === 'number') {
              shouldUnlock = habits.some(habit => habit.streak >= achievement.requirement.value);
            }
            break;
          case 'stat':
            if (typeof achievement.requirement.value === 'number') {
              const minStat = achievement.requirement.value;
              shouldUnlock = petState.happiness >= minStat && 
                            petState.health >= minStat && 
                            petState.energy >= minStat && 
                            (100 - petState.hunger) >= minStat && 
                            petState.cleanliness >= minStat;
            }
            break;
        }

        if (shouldUnlock && !achievement.unlocked) {
          updated = true;
          toast({
            title: "🎉 Achievement Unlocked!",
            description: `${achievement.icon} ${achievement.name}: ${achievement.description}`,
          });
          return { ...achievement, unlocked: true, unlockedAt: Date.now() };
        }

        return achievement;
      });

      return updated ? newAchievements : prev;
    });
  };

  useEffect(() => {
    checkAchievements();
  }, [petState, habits]);

  return achievements;
};
